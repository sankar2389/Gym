//Sandbox object
CitrusPay.Merchant.Sandbox = {
	// Merchant details
	Merchant: {
		accessKey: 'SBBQ6ZMAR9NQ3KWK5B3B',
		//accessKey: '18IZE4MDYJTCKUCJ3N67',
	        vanityUrl: 'nagama'
	}
};

//Assign object to merchant config
CitrusPay.Merchant.Config = CitrusPay.Merchant.Sandbox;


















